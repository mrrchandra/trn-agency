
import React from 'react';
import { motion } from 'framer-motion';
import { Service } from '../types';
import { LINKTREE_URL } from '../constants';
import { ArrowUpRight } from 'lucide-react';

interface ServiceCardProps {
  service: Service;
  index: number;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="group relative p-8 rounded-2xl bg-[#111111] border border-white/5 hover:border-blue-500/50 transition-all duration-300 flex flex-col h-full"
    >
      <div className="mb-6 p-3 w-fit rounded-lg bg-blue-500/10 transition-colors group-hover:bg-blue-500/20">
        {service.icon}
      </div>
      <h3 className="text-xl font-bold mb-4 text-white group-hover:text-blue-400 transition-colors">
        {service.title}
      </h3>
      <p className="text-gray-400 leading-relaxed mb-8 flex-grow">
        {service.description}
      </p>
      <a
        href={LINKTREE_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center text-sm font-bold text-white group-hover:text-blue-500 transition-colors"
      >
        Consult Now
        <ArrowUpRight className="ml-1 w-4 h-4" />
      </a>
      
      {/* Hover Background Effect */}
      <div className="absolute inset-0 rounded-2xl bg-blue-500/0 group-hover:bg-blue-500/[0.02] pointer-events-none transition-colors"></div>
    </motion.div>
  );
};

export default ServiceCard;
