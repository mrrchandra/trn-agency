
import React from 'react';
import ServiceCard from './ServiceCard';
import { SERVICES } from '../constants';

const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-[#050505]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-6">
            Elite Solutions for <span className="text-blue-500">Digital Domination</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            We provide high-impact services designed to scale your brand across multiple platforms, 
            driving engagement and real revenue.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((service, index) => (
            <ServiceCard key={service.id} service={service} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
