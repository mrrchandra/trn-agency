
import React from 'react';
import { Instagram, Twitter, Linkedin, Facebook } from 'lucide-react';
import { LINKTREE_URL } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="py-12 bg-[#050505] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-8 md:space-y-0">
          <div>
            <span className="text-2xl font-black text-white">
              TRN<span className="text-blue-500">GLOBAL</span>
            </span>
            <p className="mt-2 text-gray-500 text-sm">
              © {new Date().getFullYear()} TRN Global Agency. All rights reserved.
            </p>
          </div>
          
          <div className="flex space-x-6">
            <a href={LINKTREE_URL} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Instagram size={20} />
            </a>
            <a href={LINKTREE_URL} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Twitter size={20} />
            </a>
            <a href={LINKTREE_URL} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Linkedin size={20} />
            </a>
            <a href={LINKTREE_URL} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Facebook size={20} />
            </a>
          </div>
          
          <div>
            <a
              href={LINKTREE_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-bold text-gray-400 hover:text-white transition-colors border-b border-gray-400 hover:border-white pb-0.5"
            >
              Contact Us via Linktree
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
