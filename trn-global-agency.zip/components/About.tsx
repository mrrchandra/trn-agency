
import React from 'react';
import { motion } from 'framer-motion';
import { LINKTREE_URL } from '../constants';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-[#050505]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-8">
              More Than Just An Agency, <br />
              <span className="text-blue-500 italic">Your Growth Partner</span>
            </h2>
            <div className="space-y-6 text-gray-400 text-lg leading-relaxed">
              <p>
                TRN Global Agency is a premier digital solutions provider focused on social media growth. 
                We understand that in today's landscape, attention is currency. Our team of experts works 
                tirelessly to ensure your brand captures and converts that attention into lasting success.
              </p>
              <p>
                Whether you're looking to automate your YouTube empire or craft a stunning brand identity, 
                we bring technical expertise and creative vision to every project.
              </p>
            </div>
            <div className="mt-10">
              <a
                href={LINKTREE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center text-blue-500 font-bold text-lg hover:text-blue-400 transition-colors"
              >
                Read More About Our Mission
                <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </a>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-square rounded-3xl overflow-hidden border border-white/10">
              <img 
                src="https://picsum.photos/seed/agency-team/800/800" 
                alt="Digital Agency Office" 
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
              />
            </div>
            {/* Decorative element */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-blue-600 rounded-2xl -z-10 blur-2xl opacity-50"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
